import json
from collections import Counter

class BPETokenizer:
    def __init__(self, vocab=None, merges=None):
        self.vocab = vocab or {}
        self.merges = merges or {}
        self.inverse_vocab = {v: k for k, v in self.vocab.items()}
        
    @classmethod
    def load(cls, path):
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        vocab = {int(k): v for k, v in data["vocab"].items()}
        merges = {tuple(map(int, k.split(','))): v for k, v in data["merges"].items()}
        return cls(vocab, merges)

    def encode(self, text):
        # Перевод строки в список базовых ID символов (от 0 до N)
        chars = sorted(list(self.inverse_vocab.values()))
        stoi = {c: i for i, c in enumerate(chars)}
        tokens = [stoi.get(c, 0) for c in text]
        
        while len(tokens) >= 2:
            stats = Counter(zip(tokens[:-1], tokens[1:]))
            # Ищем самую частую пару, которую мы выучили при обучении
            pair = min(stats, key=lambda p: self.merges.get(p, float('inf')))
            if pair not in self.merges:
                break
            
            new_id = self.merges[pair]
            new_tokens = []
            j = 0
            while j < len(tokens):
                if j < len(tokens) - 1 and (tokens[j], tokens[j+1]) == pair:
                    new_tokens.append(new_id)
                    j += 2
                else:
                    new_tokens.append(tokens[j])
                    j += 1
            tokens = new_tokens
        return tokens

    def decode(self, ids):
        return "".join([self.vocab.get(i, "") for i in ids])
